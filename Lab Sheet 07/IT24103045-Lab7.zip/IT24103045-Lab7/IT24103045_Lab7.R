getwd()
setwd("C:/IT24103045-Lab7")
# Exercise 1: Train arrival X ~ Uniform(0, 40)
# Probability that the train arrives between 8:10 a.m. and 8:25 a.m. (P(10 < X < 25))
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

# Exercise 2: Software update time X ~ Exponential(lambda = 1/3)
# Probability that an update will take at most 2 hours (P(X <= 2))
pexp(2, rate = 1/3)

# Exercise 3: IQ scores X ~ Normal(mean = 100, sd = 15)
# i. Probability that a randomly selected person has an IQ above 130 (P(X > 130))
1 - pnorm(130, mean = 100, sd = 15)

# ii. IQ score that represents the 95th percentile
qnorm(0.95, mean = 100, sd = 15)
