getwd()
setwd("C:\\Users\\IT24103045\\Desktop\\IT24103045")
getwd()
branch_data <- read.table("Exercise.txt", header = TRUE)
branch_data
head(branch_data)
# Boxplot for X2 (Team Salary)
boxplot(branch_data$X2, main = "Boxplot of Sales (Team Salary)", ylab = "Salary")
# Five number summary
summary(branch_data$X2)

# IQR
IQR(branch_data$X2)
# Function to detect outliers
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR_val
  upper_bound <- Q3 + 1.5 * IQR_val
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

#Check outliers for Years (X3)
find_outliers(branch_data$X3)
