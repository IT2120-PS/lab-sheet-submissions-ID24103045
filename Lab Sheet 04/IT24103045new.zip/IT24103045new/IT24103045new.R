getwd()
setwd("C:/Users/user/OneDrive/Desktop/IT24103045new")
branch_data <- read.csv("Exercise.txt", header = TRUE)
head(branch_data)
# Boxplot for Sales
boxplot(branch_data$Sales_X1, main = "Boxplot of Sales", col = "lightblue")
# Five number summary
fivenum(branch_data$Advertising_X2)
# IQR
IQR(branch_data$Advertising_X2)
# Outlier detection function
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR_val
  upper <- Q3 + 1.5 * IQR_val
  outliers <- x[x < lower | x > upper]
  return(outliers)
}

#Check for Years variable
find_outliers(branch_data$Years_X3)
